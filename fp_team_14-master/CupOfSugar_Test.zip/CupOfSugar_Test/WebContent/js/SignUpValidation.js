function handleSubmit() {
	var fname = document.getElementById("fname").value;
	var lname = document.getElementById("lname").value;
	var password = document.getElementById("password").value;
	var email = document.getElementById("email").value;
	var typeOfUser;
	if(document.getElementById("myonoffswitch").checked){
		typeOfUser = "customer";
	}else{
		typeOfUser = "shopper";
	}
	// address - needs to be concatenated
	var address1 = document.getElementById("address1").value;
	var address2 = document.getElementById("address2").value;
	var citystate = document.getElementById("citystate").value;
	var zipcode = document.getElementById("zipcode").value;
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "SignUpError.jsp?email="+email+"&password="+password+"&fname="+fname+"&lname="+lname+
			"&typeOfUser="+typeOfUser+"&address1="+address1+"&address2="+address2+"&citystate="+citystate+"&zipcode="+zipcode, false);
	xhttp.send();
	if (xhttp.responseText.trim().length>0) {
        document.getElementById("error").innerHTML = xhttp.responseText;
        return false;
    }
	return true;
}