var socket;

function connectToServer() {
	socket = new WebSocket("ws://localhost:8080/fp_team_14/cupofsugar"); 
	
	socket.onopen = function(event) {
		console.log("Connecting");
		//document.getElementById("Status").innerHTML = "Connecting...<br/>";
	}
	
	socket.onmessage = function(event) {
		//Get the message sent to the socket
		var msg = JSON.parse(event.data);
		
		//If the message is to remove the intervals, change intervals on firebase and update frontend
		if(msg.action=='RemoveInterval'){
			//Only update the jsp for those who are looking at the same store currently
			var currentStore = document.getElementById("storeListDropdown").options[document.getElementById("storeListDropdown").selectedIndex].text;
			if(currentStore == msg.selectedStore && loggedInUserID!=msg.userID){
				var xhttp = new XMLHttpRequest();
				xhttp.open("GET", "StoreListTimeHelper.jsp?store="+currentStore,false);
				xhttp.send();
				document.getElementById("availableIntervals").innerHTML = xhttp.responseText;
			}
		}
		//If message is to add the intervals, update the frontend
		else if(msg.action=='AddInterval'){
			//Only update the jsp for customers who are looking at the same store currently
			var currentStore = document.getElementById("storeListDropdown").options[document.getElementById("storeListDropdown").selectedIndex].text;
			if(currentStore == msg.selectedStore && typeOfUser=="customer"){
				var xhttp = new XMLHttpRequest();
				xhttp.open("GET", "StoreListTimeHelper.jsp?store="+currentStore,false);
				xhttp.send();
				document.getElementById("availableIntervals").innerHTML = xhttp.responseText;
			}
		}
		//If message is customer's feedback
		else if(msg.action=='Feedback'){
			//if(loggedInUserID == msg.recipientID){
				document.getElementById("pastOrderFeedback").innerHTML = msg.feedback;
			//}
		}
		return true;
	}
	
	socket.onclose = function(event) {
		console.log("Closing");
	}	
}