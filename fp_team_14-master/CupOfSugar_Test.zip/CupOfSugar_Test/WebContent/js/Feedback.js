var loggedInUserID;


function connectShopperToServer(userID, shopperAddr, customerAddr, storeAddr){
	loggedInUserID = userID;
}
/*
 * Sends the message to the other person. Should check which checkbox is clicked and also send the messages.
 * Checkbox: getElementById("hasReceived") and "hasNotReceived"
 * Message: getElementById("feedbackText")
 */
function sendFeedbackToShopper(userID, shopperID) {
	loggedInUserId = userID;
	var feedback = document.getElementById("feedbackText").value;
	socket.send(
		JSON.stringify({
			action: 'Feedback',
			userID: self.loggedInUserID,
			recipientID: shopperID,
			feedback: feedback
		})
	);
	
}

/*
 * Sends the message to the other person. Should check which checkbox is clicked and also send the messages.
 * Checkbox: getElementById("hasDelivered") and "hasNotDelivered"
 * Message: getElementById("feedbackText")
 */
function sendFeedbackToCustomer() {

}


function toggleDeliveryFeedback() {
	if(document.getElementById("hasNotDeliveredFeedback").style.visibility == "visible") {
		document.getElementById("hasNotDeliveredFeedback").style.visibility = "hidden";
	} else {
		document.getElementById("hasNotDeliveredFeedback").style.visibility = "visible";
	}
}