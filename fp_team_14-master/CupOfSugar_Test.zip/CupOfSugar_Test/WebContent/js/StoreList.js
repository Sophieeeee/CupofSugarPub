//Initialize variables
var intervalNumber = -1;
var stores = null;
var times;
var selectedStore;
var selectedTime = -1;
var typeOfUser;
var loggedInUserID; 

/**
 * Get the available time intervals for the specified store
 */
function getAvailableIntervals(userType, userID){
	connectToServer();
	typeOfUser = userType;
	loggedInUserID = userID;
	// Save which store is selected
	selectedStore = document.getElementById("storeListDropdown")
	.options[document.getElementById("storeListDropdown").selectedIndex]
	.value;

	// Make the Http request to the jsp to load availableTimes
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET","StoreListTimeHelper.jsp?store="+selectedStore,false);
	xhttp.send();

	// Change the innerHTML
	document.getElementById("availableIntervals").innerHTML = xhttp.responseText;
}

/**
 * Stores the interval that the customer has chosen.
 */
function storeInterval (value)
{
	intervalNumber = value;
}

function sendCustomerInterval(){
		//First change the status of the chosen interval to pending
		socket.send(
			JSON.stringify({
				action: 'RemoveInterval',
				selectedStore: self.selectedStore,
				userID: self.loggedInUserID,
			})
		);
		return true;
}
/**
 * Update firebase with which interval customer picked to dynamically change other clients' webpage
 */
function validateInterval ()
{
	// Default if they hit submit before picking an option
	if (intervalNumber == -1) {
		document.getElementById("error").innerHTML = "You must select an interval <br/>";
		return false;
	}else{
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET","RemoveCustomerInterval.jsp?interval="+intervalNumber+"&store="+selectedStore,false);
		xhttp.send();
		sendCustomerInterval();
		return true;
	}
	// would have to change the database
}

/**
 * Stores the time that the shopper is available for
 */
function storeShopperTime()
{
	// Save the time the shopper selected 
	selectedTime = document
	.getElementById("timeOptionsDropdown")
	.options[document.getElementById("timeOptionsDropdown").selectedIndex]
	.value;
}

/**
 * Send the interval that the shopper picked to firebase and update the customers' webpage
 */
function sendIntervalToDB ()
{
	// Default if they hit submit before picking an option
	if (selectedTime == -1) {
		document.getElementById("error").innerHTML = "You must select an interval <br/>";
		return false;
	}else{
		// Make the Http request to the jsp to load availableTimes
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET","AddShopperInterval.jsp?store="+self.selectedStore+"&interval="+self.selectedTime,false);
		xhttp.send();
		sendShopperInterval();
	}
}

function sendShopperInterval(){
	socket.send(
			JSON.stringify({
				action: 'AddInterval',
				selectedStore: self.selectedStore,
			})
	);
	window.location.href = '../jsp/CustomerHomepage.jsp';
}