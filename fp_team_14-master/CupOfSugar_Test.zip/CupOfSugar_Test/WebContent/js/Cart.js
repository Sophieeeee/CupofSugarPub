var selectedCategory;
var itemQuantities = new Map();
var tempQuantity = -1;
/**
 * Queries firebase for all of the items in a given store.
 */
function getAvailableItems(store) {
	var items = ["Apple", "Banana", "Cherries"];
	var prices = [1, 2, 3];
	displayItems(items, store, prices);
}

/**
 *  Changes the innerHTML of itemsList to display all of the items
 */
function displayItems(items, store, prices) {
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "ItemsHelper.jsp?items="+items+"&store="+store+"&prices="+prices, false);
	xhttp.send();
	if (xhttp.responseText.trim().length > 0) {
		document.getElementById("itemsList").innerHTML = xhttp.responseText;
	}
}
/**
 * Updates the price dynamically when clicked.
 * Should query the JSON object or database or something for
 * the price associated with itemName.
 */
function changeTotalPrice(itemPriceTemp, quantity) {
	var newTotal = 0.00;
	var itemPrice = 0.00;
	itemPrice += parseFloat(itemPriceTemp);
	var oldPrice = document.getElementById("totalPrice").innerHTML;
	if(quantity < tempQuantity) {
		//subtract
		newTotal = parseFloat(oldPrice.substr(1, oldPrice.length)) - itemPrice;
		
	} else {
		//add
		newTotal = parseFloat(oldPrice.substr(1, oldPrice.length)) + itemPrice;
	}
	document.getElementById("totalPrice").innerHTML = "$" + newTotal.toFixed(2);
}

function addItemToCart(itemID, itemPrice){
	var tempItemID = "itemID"+itemID;
	var quantity = document.getElementById(tempItemID).value;
	if(itemQuantities.get(itemID)==undefined){
		//empty
		tempQuantity=-1;
		itemQuantities.set(itemID, parseInt(quantity));
	} else {
		//not empty
		tempQuantity = parseInt(itemQuantities.get(itemID));
		itemQuantities.set(itemID, parseInt(quantity));
	}
	changeTotalPrice(itemPrice, quantity);
	
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "ItemsHelper.jsp?itemID="+itemID+"&quantity="+quantity+"&itemPrice="+itemPrice, false);
	xhttp.send();
}

/**
 * Given the customer UUID, queries the database to find
 * the shopper and change their status to available.
 */

function cancelOrder() {
	window.location.href = '../jsp/CustomerHomepage.jsp';
}

/**
 * Should forward to the Checkout page
 */
function checkoutOrder() {
	//get total price
	var oldPrice = document.getElementById("totalPrice").innerHTML;
	var totalPrice = parseFloat(oldPrice.substr(1, oldPrice.length));
	window.location.href = '../jsp/Checkout.jsp?totalPrice='+totalPrice;
}

/**
 * Should add the order to the database
 * @returns
 */
function confirmOrder(loggedInUserID, inAppCurrency, totalPrice){
	if(loggedInUserID==1){
		document.getElementById("error").innerHTML = "Sorry, you must be a registered user to checkout!";
		document.getElementById("signUpGuestButton").style.visibility = "visible";
	} else if(inAppCurrency < totalPrice) {
		document.getElementById("error").innerHTML = "Sorry, you do not have enough money!";
		document.getElementById("backToItemsButton").style.visibility = "visible";
	} else {
		window.location.href = '../jsp/CustomerConfirmation.jsp';
	}
	
}

/**
 * Get the items for the specified category
 */
function getAvailableItems(category){
	// Save which category is selected
	selectedCategory = document.getElementById("categoryListDropdown")
	.options[document.getElementById("categoryListDropdown").selectedIndex]
	.text;

	// Make the Http request to the jsp to load availableItems
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET","ItemsHelper.jsp?category="+category,false);
	xhttp.send();

	// Change the innerHTML
	document.getElementById("availableIntervals").innerHTML = xhttp.responseText;
}