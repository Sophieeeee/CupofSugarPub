Creators: Eddo Hintoso, Nandhini Namasivayam, Maya Ram, Zixin Wang, 

In the coming days, we will implement slight adjustments to our frontend through
the css files. In addition, we will slightly edit the backend to better the real-time 
connection between customer and shopper.