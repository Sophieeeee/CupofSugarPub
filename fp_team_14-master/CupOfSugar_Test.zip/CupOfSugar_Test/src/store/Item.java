package store;

public class Item {
	private String name;
	private int itemID;
	private float price;
	private String img;

	public Item(int itemID, float p) {
		this.itemID = itemID;
		price = p;
	}

	public void setName(String name){
		this.name = name;
	}
	public String getName() {
		return name;
	}
	
	public void setImage(String img){
		this.img = img;
	}
	public String getImage(){
		return this.img;
	}

	public float getPrice() {
		return price;
	}

	public int getItemID(){
		return this.itemID;
	}

}
