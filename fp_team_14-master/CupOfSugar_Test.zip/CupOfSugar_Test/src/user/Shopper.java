package user;

public class Shopper extends User {

}
