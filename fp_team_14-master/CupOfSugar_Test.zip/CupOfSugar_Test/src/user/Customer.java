package user;

public class Customer extends User {

	private Cart cart;

}
